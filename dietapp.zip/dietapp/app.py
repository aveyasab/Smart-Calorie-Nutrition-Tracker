import streamlit as st
import pandas as pd
import altair as alt

# ================== KONFIGURASI ==================
st.set_page_config(
    page_title="Smart Calorie & Nutrition Tracker",
    page_icon="🍎",
    layout="centered"
)

# ================== STYLE TAMBAHAN ==================
st.markdown("""
<style>
.big-title {
    font-size:32px;
    font-weight:700;
}
.card {
    background-color:#f9f9f9;
    padding:20px;
    border-radius:15px;
    margin-bottom:15px;
}
</style>
""", unsafe_allow_html=True)

# ================== SESSION STATE ==================
if "page" not in st.session_state:
    st.session_state.page = 1

if "user" not in st.session_state:
    st.session_state.user = {}

if "meals" not in st.session_state:
    st.session_state.meals = []

# ================== PAGE 1 ==================
def page_data_pengguna():
    st.markdown("<div class='big-title'>👤 Data Pengguna</div>", unsafe_allow_html=True)
    st.write("Masukkan data diri untuk memulai analisis gizi harianmu.")

    with st.container():
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        nama = st.text_input("Nama")
        umur = st.number_input("Umur", min_value=1, max_value=100)
        jk = st.selectbox("Jenis Kelamin", ["Pilih", "Laki-laki", "Perempuan"])
        st.markdown("</div>", unsafe_allow_html=True)

    if st.button("🚀 Simpan & Lanjut"):
        if nama == "" or jk == "Pilih":
            st.error("Semua data wajib diisi")
        else:
            st.session_state.user = {"nama": nama, "umur": umur, "jk": jk}
            st.session_state.page = 2
            st.rerun()

# ================== PAGE 2 ==================
def page_input_makanan():
    st.markdown("<div class='big-title'>🍽 Input Makanan</div>", unsafe_allow_html=True)
    st.write("Masukkan makanan yang kamu konsumsi hari ini (bebas).")

    with st.container():
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        makanan = st.text_input("Nama makanan")
        kalori = st.number_input("Total kalori (kkal)", min_value=0)
        st.markdown("</div>", unsafe_allow_html=True)

    if st.button("➕ Tambah Makanan"):
        if makanan == "" or kalori == 0:
            st.error("Nama makanan dan kalori wajib diisi")
        else:
            protein = (kalori * 0.20) / 4
            karbo = (kalori * 0.50) / 4
            lemak = (kalori * 0.30) / 9
            serat = karbo * 0.10
            gula = karbo * 0.20

            st.session_state.meals.append({
                "makanan": makanan,
                "kalori": kalori,
                "protein": protein,
                "karbo": karbo,
                "lemak": lemak,
                "serat": serat,
                "gula": gula
            })

            st.success(f"{makanan} berhasil ditambahkan")

    if st.session_state.meals:
        st.subheader("📋 Riwayat Makanan")
        for i, m in enumerate(st.session_state.meals, 1):
            st.write(f"{i}. {m['makanan']} — {m['kalori']} kkal")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("⬅ Kembali"):
            st.session_state.page = 1
            st.rerun()
    with col2:
        if st.button("Lanjut ➡"):
            st.session_state.page = 3
            st.rerun()

# ================== PAGE 3 ==================
def page_total_kalori():
    st.markdown("<div class='big-title'>🔥 Total Kalori</div>", unsafe_allow_html=True)

    total_kalori = sum(m["kalori"] for m in st.session_state.meals)

    st.metric("Total Kalori Harian", f"{total_kalori:.0f} kkal")

    if st.button("📊 Lihat Analisis Gizi"):
        st.session_state.page = 4
        st.rerun()

# ================== PAGE 4 ==================
def page_analisis_gizi():
    st.markdown("<div class='big-title'>📊 Analisis Gizi</div>", unsafe_allow_html=True)

    total = {"kalori":0,"protein":0,"karbo":0,"lemak":0,"serat":0,"gula":0}
    for m in st.session_state.meals:
        for k in total:
            total[k] += m[k]

    st.subheader("🔎 Ringkasan Asupan")
    st.write(f"🔥 Kalori: {total['kalori']:.0f} kkal")
    st.write(f"🥩 Protein: {total['protein']:.1f} g")
    st.write(f"🍚 Karbohidrat: {total['karbo']:.1f} g")
    st.write(f"🥑 Lemak: {total['lemak']:.1f} g")
    st.write(f"🥦 Serat: {total['serat']:.1f} g")
    st.write(f"🍬 Gula: {total['gula']:.1f} g")

    # ================== GRAFIK ANTI MAINSTREAM ==================
    st.subheader("📈 Visualisasi Asupan Gizi")

    df = pd.DataFrame({
        "Gizi": ["Protein", "Karbo", "Lemak", "Serat", "Gula"],
        "Jumlah (gram)": [
            total["protein"],
            total["karbo"],
            total["lemak"],
            total["serat"],
            total["gula"]
        ]
    })

    chart = alt.Chart(df).mark_arc(innerRadius=50).encode(
        theta="Jumlah (gram)",
        color="Gizi",
        tooltip=["Gizi", "Jumlah (gram)"]
    ).properties(height=300)

    st.altair_chart(chart, use_container_width=True)

    st.subheader("📌 Evaluasi & Rekomendasi")
    kurang = False

    def rekomendasi(judul, teks, img, caption):
        with st.container():
            st.warning(teks)
            col1, col2 = st.columns([1, 3])
            with col1:
                st.image(img, use_container_width=True)
            with col2:
                st.markdown(f"**{caption}**")
            st.divider()

    # PROTEIN
    if total["protein"] < 50:
        kurang = True
        rekomendasi(
            "Protein",
            "Protein masih kurang",
            "https://upload.wikimedia.org/wikipedia/commons/3/3a/Roast_chicken.jpg",
            "🍗 Ayam — sumber protein tinggi"
        )

    # KARBOHIDRAT
    if total["karbo"] < 225:
        kurang = True
        rekomendasi(
            "Karbohidrat",
            "Karbohidrat masih kurang",
            "https://upload.wikimedia.org/wikipedia/commons/8/8f/Oatmeal.jpg",
            "🥣 Oatmeal — sumber karbohidrat kompleks"
        )

    # LEMAK SEHAT
    if total["lemak"] < 60:
        kurang = True
        rekomendasi(
            "Lemak Sehat",
            "Lemak sehat masih kurang",
            "https://upload.wikimedia.org/wikipedia/commons/c/c4/Avocado_Hass.jpg",
            "🥑 Alpukat — lemak sehat alami"
        )

    # SERAT
    if total["serat"] < 25:
        kurang = True
        rekomendasi(
            "Serat",
            "Serat masih kurang",
            "https://upload.wikimedia.org/wikipedia/commons/0/03/Broccoli_and_cross_section_edit.jpg",
            "🥦 Brokoli — kaya serat"
        )

    # GULA
    if total["gula"] < 25:
        kurang = True
        rekomendasi(
            "Gula Alami",
            "Gula alami masih kurang",
            "https://upload.wikimedia.org/wikipedia/commons/1/15/Red_Apple.jpg",
            "🍎 Apel — gula alami"
        )
